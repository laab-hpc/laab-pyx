#!/bin/bash
#SBATCH --job-name=CPU-1x
#SBATCH --time=00:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=1
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C zen4

set -euo pipefail

module purge
module load GCC/12.3.0 OpenMPI/4.1.5
module load TensorFlow/2.15.1

export LD_BLAS='-lopenblas'
export OMP_NUM_THREADS=1
export LAAB_REPS=10
export LAAB_N=3000

SRC_DIR="/proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/src/steps/t3-matchain"
LIB_DIR="TensorFlow-v2"

mkdir -p logs/

lscpu > logs/cpu_info.txt

echo "Test-3-Matrix-Chains" > logs/metadata.txt
echo CPU-1x >> logs/metadata.txt
echo kebnekaise:zen4 >> logs/metadata.txt
echo TensorFlow >> logs/metadata.txt
echo 2.15.1 >> logs/metadata.txt
echo foss-2023a >> logs/metadata.txt

echo "REP=${LAAB_REPS} benchmark.exe ${LAAB_N}" > logs/data.txt

srun python "${SRC_DIR}/rtol/cpu-mt/${LIB_DIR}/matchain_rtol.py" | tee -a logs/data.txt
cp "${SRC_DIR}/rtol/cpu-mt/${LIB_DIR}/config.json" logs/matchain_rtol.json

srun python "${SRC_DIR}/ltor/cpu-mt/${LIB_DIR}/matchain_ltor.py" | tee -a logs/data.txt
cp "${SRC_DIR}/ltor/cpu-mt/${LIB_DIR}/config.json" logs/matchain_ltor.json

srun python "${SRC_DIR}/mixed/cpu-mt/${LIB_DIR}/matchain_mixed.py" | tee -a logs/data.txt
cp "${SRC_DIR}/mixed/cpu-mt/${LIB_DIR}/config.json" logs/matchain_mixed.json

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/venvs/pyx-kebnekaise/activate.sh

pyx-process-logs logs/ --out_dir ../../../profiles
