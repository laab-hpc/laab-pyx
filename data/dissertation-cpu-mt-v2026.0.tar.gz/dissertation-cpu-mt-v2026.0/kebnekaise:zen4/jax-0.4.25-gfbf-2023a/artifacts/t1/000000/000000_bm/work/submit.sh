#!/bin/bash
#SBATCH --job-name=CPU-1x
#SBATCH --time=00:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1           
#SBATCH --cpus-per-task=1
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C zen4

set -euo pipefail

module purge
module load GCC/12.3.0 OpenMPI/4.1.5
module load jax/0.4.25

export LD_BLAS='-lopenblas'
export OMP_NUM_THREADS=1
export LAAB_REPS=10
export LAAB_N=3000

SRC_DIR="/proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/src/steps/t1-matmul"
LIB_DIR="jax-v0"

export LAAB_BUILD_DIR=$(pwd)/build

mkdir -p logs/

lscpu > logs/cpu_info.txt

echo "Test-1-Matmul" > logs/metadata.txt
echo CPU-1x >> logs/metadata.txt
echo kebnekaise:zen4 >> logs/metadata.txt
echo jax >> logs/metadata.txt
echo 0.4.25 >> logs/metadata.txt
echo gfbf-2023a >> logs/metadata.txt

srun make --no-print-directory -C "${SRC_DIR}/gemm/cpu-mt/C"
srun make --no-print-directory -C "${SRC_DIR}/gemm/cpu-mt/C" run | tee -a logs/data.txt
srun make --no-print-directory -C "${SRC_DIR}/gemv/cpu-mt/C"
srun make --no-print-directory -C "${SRC_DIR}/gemv/cpu-mt/C" run | tee -a logs/data.txt
srun make --no-print-directory -C "${SRC_DIR}/syrk/cpu-mt/C"
srun make --no-print-directory -C "${SRC_DIR}/syrk/cpu-mt/C" run | tee -a logs/data.txt
srun make --no-print-directory -C "${SRC_DIR}/trmm/cpu-mt/C"
srun make --no-print-directory -C "${SRC_DIR}/trmm/cpu-mt/C" run | tee -a logs/data.txt
srun make --no-print-directory -C "${SRC_DIR}/tridiag/cpu-mt/C"
srun make --no-print-directory -C "${SRC_DIR}/tridiag/cpu-mt/C" run | tee -a logs/data.txt

srun python "${SRC_DIR}/gemm/cpu-mt/${LIB_DIR}/mm_sgemm.py" | tee -a logs/data.txt
cp "${SRC_DIR}/gemm/cpu-mt/${LIB_DIR}/config.json" logs/mm_sgemm.json

srun python "${SRC_DIR}/syrk/cpu-mt/${LIB_DIR}/mm_syrk.py" | tee -a logs/data.txt
cp "${SRC_DIR}/syrk/cpu-mt/${LIB_DIR}/config.json" logs/mm_syrk.json

srun python "${SRC_DIR}/trmm/cpu-mt/${LIB_DIR}/mm_trmm.py" | tee -a logs/data.txt
cp "${SRC_DIR}/trmm/cpu-mt/${LIB_DIR}/config.json" logs/mm_trmm.json

srun python "${SRC_DIR}/tridiag/cpu-mt/${LIB_DIR}/mm_tridiag.py" | tee -a logs/data.txt
cp "${SRC_DIR}/tridiag/cpu-mt/${LIB_DIR}/config.json" logs/mm_tridiag.json

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/venvs/pyx-kebnekaise/activate.sh

pyx-process-logs logs/ --out_dir ../../../profiles

