#!/bin/bash
#SBATCH --job-name=CPU-4x
#SBATCH --time=00:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C zen4

set -euo pipefail

module purge
module load GCC/12.3.0 OpenMPI/4.1.5
module load jax/0.4.25

export LD_BLAS='-lopenblas'
export OMP_NUM_THREADS=4
export LAAB_REPS=10
export LAAB_N=3000

SRC_DIR="/proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/src/steps/t4-expr_rewrite"
LIB_DIR="jax-v0"

mkdir -p logs/

lscpu > logs/cpu_info.txt

echo "Test-4-Expression-Rewrites" > logs/metadata.txt
echo CPU-4x >> logs/metadata.txt
echo kebnekaise:zen4 >> logs/metadata.txt
echo jax >> logs/metadata.txt
echo 0.4.25 >> logs/metadata.txt
echo gfbf-2023a >> logs/metadata.txt

echo "REP=${LAAB_REPS} benchmark.exe ${LAAB_N}" > logs/data.txt

srun python "${SRC_DIR}/distributivity1/cpu-mt/${LIB_DIR}/am_distributivity1.py" | tee -a logs/data.txt
cp "${SRC_DIR}/distributivity1/cpu-mt/${LIB_DIR}/config.json" logs/am_distributivity1.json

srun python "${SRC_DIR}/distributivity2/cpu-mt/${LIB_DIR}/am_distributivity2.py" | tee -a logs/data.txt
cp "${SRC_DIR}/distributivity2/cpu-mt/${LIB_DIR}/config.json" logs/am_distributivity2.json

srun python "${SRC_DIR}/transpose/cpu-mt/${LIB_DIR}/am_transpose.py" | tee -a logs/data.txt
cp "${SRC_DIR}/transpose/cpu-mt/${LIB_DIR}/config.json" logs/am_transpose.json

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/venvs/pyx-kebnekaise/activate.sh

pyx-process-logs logs/ --out_dir ../../../profiles
