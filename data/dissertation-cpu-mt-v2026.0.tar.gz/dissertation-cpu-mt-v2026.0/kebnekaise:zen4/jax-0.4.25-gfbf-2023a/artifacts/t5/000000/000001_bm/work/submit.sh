#!/bin/bash
#SBATCH --job-name=CPU-4x
#SBATCH --time=00:30:00
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=4
#SBATCH --output=slurm.out
#SBATCH --error=slurm.err
#SBATCH -A hpc2n2026-184
#SBATCH -C zen4

set -euo pipefail

module purge
module load GCC/12.3.0 OpenMPI/4.1.5
module load jax/0.4.25

export LD_BLAS='-lopenblas'
export OMP_NUM_THREADS=4
export LAAB_REPS=10
export LAAB_N=3000

SRC_DIR="/proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/src/steps/t5-code_motion"
LIB_DIR="jax-v0"

mkdir -p logs/

lscpu > logs/cpu_info.txt

echo "Test-5-Code-Motion" > logs/metadata.txt
echo CPU-4x >> logs/metadata.txt
echo kebnekaise:zen4 >> logs/metadata.txt
echo jax >> logs/metadata.txt
echo 0.4.25 >> logs/metadata.txt
echo gfbf-2023a >> logs/metadata.txt

echo "REP=${LAAB_REPS} benchmark.exe ${LAAB_N}" > logs/data.txt

srun python "${SRC_DIR}/loops/cpu-mt/${LIB_DIR}/cm_loops.py" | tee -a logs/data.txt
cp "${SRC_DIR}/loops/cpu-mt/${LIB_DIR}/config.json" logs/cm_loops.json

srun python "${SRC_DIR}/partial-op-sum/cpu-mt/${LIB_DIR}/cm_partial_op_sum.py" | tee -a logs/data.txt
cp "${SRC_DIR}/partial-op-sum/cpu-mt/${LIB_DIR}/config.json" logs/cm_partial_op_sum.json

srun python "${SRC_DIR}/partial-op-prod/cpu-mt/${LIB_DIR}/cm_partial_op_prod.py" | tee -a logs/data.txt
cp "${SRC_DIR}/partial-op-prod/cpu-mt/${LIB_DIR}/config.json" logs/cm_partial_op_prod.json

source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/venvs/pyx-kebnekaise/activate.sh

pyx-process-logs logs/ --out_dir ../../../profiles
