#!/bin/bash

module purge
module load GCC/14.3.0 SciPy-bundle
source /proj/nobackup/aravind/LAAB-HPC/benchmarks/laab-pyx/venv/bin/activate

mkdir -p ../../../profiles

pyx-process-logs data.txt --outfile profile.pkl --name "CPU-1x" --system "kebnekaise:skylake" \
    --lib "jax" --version "0.4.25" --toolchain "gfbf-2023a" \
    --config_path ../../src/config.json --prob_siz "3000" --reps "10" --omp_num_threads "1"

pyx-prepare-md-report profile.pkl --outfile README.md

mv profile.pkl ../../../profiles/profile_1_0.pkl
mv README.md ../../../profiles/README_1_0.md